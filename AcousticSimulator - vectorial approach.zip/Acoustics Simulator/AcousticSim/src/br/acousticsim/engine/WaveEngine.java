package br.acousticsim.engine;


/**
 *This engine transforms an wav into a representation of the sound being reproduced in the scenery. The input wave is located in scenery by an SoundSource object and the output is captured by a SoundListener object in scenery.
 */
public class WaveEngine {
 
}
 
