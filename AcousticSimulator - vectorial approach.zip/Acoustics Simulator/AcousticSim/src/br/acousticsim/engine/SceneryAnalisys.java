package br.acousticsim.engine;

import br.acousticsim.scenery.AcousticScenery;


/**
 *This analisys represents an analysis based on the overall scenery acoustic characteristics.
 */
public class SceneryAnalisys {
 
	private AcousticScenery acousticScenery;
	 
}
 
