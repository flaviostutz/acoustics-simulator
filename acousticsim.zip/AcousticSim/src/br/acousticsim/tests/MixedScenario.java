package br.acousticsim.tests;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PickRay;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import br.acousticsim.engine.ReflectionEngine;
import br.acousticsim.engine.ReflectionsResult;
import br.acousticsim.math.Geometries;
import br.acousticsim.scenery.AcousticScenery;

import com.sun.j3d.utils.geometry.ColorCube;

public class MixedScenario extends AcousticScenery {

	@Override
	public BranchGroup createSceneGraph() {

		// Create the root of the branch graph
		BranchGroup objRoot = new BranchGroup();

		ColorCube cube = new ColorCube(0.1);
		
		Shape3D triangle1 = Geometries.createTriangle(new Point3d(1.1,0,0), new Point3d(0,1,0), new Point3d(0,0,1));
		Shape3D triangle2 = Geometries.createTriangle(new Point3d(-1,0,0), new Point3d(0,-1,0), new Point3d(0,0,-1));
		
		Shape3D triangle3 = Geometries.createTriangle(new Point3d(1.2,0,0), new Point3d(0,0,-1.2), new Point3d(0,-1.2,0));
		Shape3D triangle4 = Geometries.createTriangle(new Point3d(0,1.2,0), new Point3d(-1.2,0,0), new Point3d(0,0,-1.2));

		TransparencyAttributes ta = new TransparencyAttributes();
		ta.setTransparencyMode(TransparencyAttributes.BLEND_SRC_ALPHA);
		ta.setTransparency(.5F);
		
		Appearance a = new Appearance();
		a.setTransparencyAttributes(ta);
		cube.setAppearance(a);

		triangle1.getAppearance().getColoringAttributes().setColor(255,0,0);
		triangle1.getAppearance().setTransparencyAttributes(ta);
		triangle2.getAppearance().getColoringAttributes().setColor(0,255,0);
		triangle2.getAppearance().setTransparencyAttributes(ta);
		triangle3.getAppearance().getColoringAttributes().setColor(0,0,255);
		triangle3.getAppearance().setTransparencyAttributes(ta);
		triangle4.getAppearance().getColoringAttributes().setColor(127,0,127);
		triangle4.getAppearance().setTransparencyAttributes(ta);
		
		objRoot.addChild(cube);
		objRoot.addChild(triangle1);
		objRoot.addChild(triangle2);
		objRoot.addChild(triangle3);
		objRoot.addChild(triangle4);

		//criar um raio a ser emitido contra o cen�rio
//		PickRay ray = new PickRay(new Point3d(-0.15,-0.15,-0.15), new Vector3d(0.8,1.2,0.7));//RAIO SAINDO DA CAIXA
//		PickRay ray = new PickRay(new Point3d(0,0,0), new Vector3d(0.1,0.5,1));
//		PickRay ray = new PickRay(new Point3d(0.08,0,0.1), new Vector3d(0.02,0.1,-0.05));//RAIO SAINDO DA CAIXA
//		PickRay ray = new PickRay(new Point3d(-0.05,-0.1,0.05), new Vector3d(-0.07,0.1,0.05));//RAIO SAINDO DA CAIXA
		PickRay ray = new PickRay(new Point3d(-0.21, -0.23, -0.18), new Vector3d(0.45,0.42,0.4));
//		PickRay ray = new PickRay(new Point3d(-0.2, -0.2, -0.2), new Vector3d(0.4,0.5,0.4));//RAIO ATINGINDO A BORDA DA CAIXA

		//calcular reflex�es sucessivas do raio no cen�rio
		ReflectionsResult rr = ReflectionEngine.computeRayReflections(objRoot, 8, ray);
		ReflectionEngine.addRayReflectionLinesToGroup(rr, objRoot);

		//otimizar a cena
		objRoot.compile();

		return objRoot;
	}

	private static final long serialVersionUID = 3258126947169874738L;

}
