package br.acousticsim.tests;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PickRay;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import br.acousticsim.engine.ReflectionEngine;
import br.acousticsim.engine.ReflectionsResult;
import br.acousticsim.scenery.AcousticScenery;

import com.sun.j3d.utils.geometry.ColorCube;

public class CubeScenario extends AcousticScenery {

	@Override
	public BranchGroup createSceneGraph() {

		// Create the root of the branch graph
		BranchGroup objRoot = new BranchGroup();

		ColorCube cube = new ColorCube(0.5);
		TransparencyAttributes ta = new TransparencyAttributes();
		ta.setTransparencyMode(TransparencyAttributes.BLEND_SRC_ALPHA);
		ta.setTransparency(.5F);
		Appearance a = new Appearance();
		a.setTransparencyAttributes(ta);
		cube.setAppearance(a);
		objRoot.addChild(cube);

		//criar um raio a ser emitido contra o cen�rio
		PickRay ray = new PickRay(new Point3d(0.15,0.15,0.15), new Vector3d(0.8,1.2,0.7));//REFLEX�ES NAO COINCIDENTES
//		PickRay ray = new PickRay(new Point3d(0,0,0), new Vector3d(0.1,0.5,1));//OK!
//		PickRay ray = new PickRay(new Point3d(-0.4, -0.5, 0.100000024), new Vector3d(0.05,0.2,1));//OK!
//		PickRay ray = new PickRay(new Point3d(-1, 0, 0), new Vector3d(1,1,1));

		//calcular reflex�es sucessivas do raio no cen�rio
		ReflectionsResult rr = ReflectionEngine.computeRayReflections(objRoot, 50, ray);
		ReflectionEngine.addRayReflectionLinesToGroup(rr, objRoot);

		//otimizar a cena
		objRoot.compile();

		return objRoot;
	}

	private static final long serialVersionUID = 3258413945491632181L;

}
