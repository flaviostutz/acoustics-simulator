package br.acousticsim.scenery;

import br.acousticsim.engine.SoundListenerAnalisys;


/**
 *Input source placed in space for calculations of the acoustic characteristics in a certain point.
 */
public class SoundListener extends DirectionalTool {
 
	private SoundListenerAnalisys soundListenerAnalisys;
	 
	private AcousticScenery acousticScenery;
	 
}
 
