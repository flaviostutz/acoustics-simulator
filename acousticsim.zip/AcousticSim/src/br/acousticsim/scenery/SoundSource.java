package br.acousticsim.scenery;


/**
 *Sound source in space for performing analisys.
 */
public class SoundSource extends DirectionalTool {
 
}
 
