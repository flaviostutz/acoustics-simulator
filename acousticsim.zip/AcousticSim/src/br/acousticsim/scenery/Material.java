package br.acousticsim.scenery;


/**
 *Material related to a vertex in AcousticGeometry.
 */
public class Material {
 
}
 
