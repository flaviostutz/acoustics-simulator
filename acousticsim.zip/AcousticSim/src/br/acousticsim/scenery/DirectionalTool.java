package br.acousticsim.scenery;

import javax.media.j3d.Shape3D;


/**
 *Aperture size of Tool and direction of tool in space.
 */
public class DirectionalTool extends Shape3D {
 
}
 
