package br.acousticsim.scenery;

import java.util.HashSet;
import java.util.Set;
import javax.media.j3d.Shape3D;
import br.acousticsim.math.Physics;

public class AcousticScenery {
	SceneryAnalysis sceneryAnalysis;
	Set<Shape3D> shapes;
	float airTemp = 25;//default temperature
	
	public AcousticScenery() {
		shapes = new HashSet<Shape3D>();
		sceneryAnalysis = null;
	}
	
	public void addShape(Shape3D shape) {
		shapes.add(shape);
	}
	
	public Set<Shape3D> getShapes() {
		return shapes;
	}
	
	public void setAirTemperature(float airTempCelsius) {
		this.airTemp = airTempCelsius;
	}
	
	public float getAirSoundVelocity() {
		return Physics.getAirSoundVelocity(airTemp);
	}
	
}
