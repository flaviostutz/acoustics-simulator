package br.acousticsim.engine;

import java.util.HashSet;
import java.util.Set;

import javax.media.j3d.Shape3D;

import br.acousticsim.scenery.AcousticScenery;
import br.acousticsim.scenery.SoundListener;
import br.acousticsim.scenery.SoundSource;


/**
 *Performs the necessary operations to analyse a scenery, based on its objects, SoundSources and SoundListeners.
 */
public class AcousticAnalisysEngine {
	
	public void runAnalysis(AcousticScenery scenery) {

		Set<SoundSource> soundSources = new HashSet<SoundSource>();
		Set<SoundListener> soundListeners = new HashSet<SoundListener>();
		
		Set<Shape3D> shapes = scenery.getShapes(); 
		for(Shape3D shape: shapes) {
			if(shape instanceof SoundSource) {
				soundSources.add((SoundSource)shape);
				
			} else if (shape instanceof SoundListener) {
				soundListeners.add((SoundListener)shape);
				
			}
		}
	}
	
}
 
