package br.acousticsim.engine;


/**
 *Reverberation spectrum read from a SoundListener
 */
public class ReverberationSpectrum {
 
}
 
