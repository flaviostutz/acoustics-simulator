package br.acousticsim.engine;

import java.util.Vector;

import javax.media.j3d.Group;
import javax.media.j3d.PickRay;

/**
 * Guarda o resultado do processamento de um raio em um certo grupo de objetos
 * @author f3310193
 */
public class ReflectionsResult {

	Vector<ReflectionInfo> reflections;
	PickRay ray;
	Group group;
	int maxNumberOfReflectionsAnalysed;

	
	
	/**
	 * @param reflections
	 * @param ray
	 * @param group
	 * @param numberOfReflections
	 */
	public ReflectionsResult(Vector<ReflectionInfo> reflections, PickRay ray,
			Group group, int maxNumberOfReflectionsAnalysed) {
		super();
		this.reflections = reflections;
		this.ray = ray;
		this.group = group;
		this.maxNumberOfReflectionsAnalysed = maxNumberOfReflectionsAnalysed;
	}
	/**
	 * @return Returns the group.
	 */
	public Group getGroup() {
		return group;
	}
	/**
	 * @return Returns the numberOfReflections.
	 */
	public int getMaxNumberOfReflections() {
		return maxNumberOfReflectionsAnalysed;
	}
	/**
	 * @return Returns the ray.
	 */
	public PickRay getRay() {
		return ray;
	}
	/**
	 * @return Returns the reflections.
	 */
	public Vector<ReflectionInfo> getReflections() {
		return reflections;
	}
}
