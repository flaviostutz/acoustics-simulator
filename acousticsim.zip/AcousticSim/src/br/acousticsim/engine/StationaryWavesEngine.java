package br.acousticsim.engine;


/**
 *This engine tries to find serious stationary waves in scenery.
 */
public class StationaryWavesEngine {
 
}
 
