package br.acousticsim.engine;

import br.acousticsim.scenery.SoundListener;


/**
 *Result of acoustic analisys based on a SoundListener
 */
public class SoundListenerAnalisys {
 
	private SoundListener soundListener;
	 
	private ReverberationSpectrum reverberationSpectrum;
	 
}
 
